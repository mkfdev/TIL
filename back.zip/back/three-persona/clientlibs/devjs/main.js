(function (win, $, doc) {
    'use strict';
    win.smg = win.smg || {};
    win.smg.support = win.smg.support || {};
    win.smg.support.common = win.smg.support.common || {};

    var CST_EVENT = win.smg.support.common.customEvent,
        BREAKPOINTS = win.smg.support.common.breakpoints,
        UTIL = win.smg.support.common.util,
        PAGE = win.smg.support.page,
        pluginName = 'threePersona';

    win.smg.support[pluginName] = function (container, args) {
        var defParams = {
            obj : container,
            topics : '.topics',
            topicsList : '.topics__list',
            productWrap : '.select-product__wrap',
            product : '.select-product',
            productList : '.select-product__list',
            productClose : '.select-product__btn-close',
            category : '.find-category',
            categoryStep : '.find-category__step',
            categoryTitle : '.find-category__title',
            categoryName : '.find-category__name',
            categoryList : '.find-category__listing',
            categoryListUl : '.listing',
            categoryStepSort : '.find-category__step-sort',
            categoryResult : '.find-category__result',
            categoryActiveClass : 'find-category--active',
            titleActiveClass : 'title-active',
            sortActiveClass : 'sort-active',
            newWindowClass : 's-ico-new-window',
            categoryViewType : false,
            customEvent : '.' + pluginName + (new Date()).getTime(),
            duration : 250,
            breakpointsMode : null,
            resizeStart : null,
            loadAfter : null
        };
        this.opts = UTIL.def(defParams, (args || {}));
        if (!(this.obj = $(this.opts.obj)).length) return;
        this.init();
    };
    win.smg.support[pluginName].prototype = {
        init : function () {
            this.setElements();
            this.initLayout();
            this.resizeFunc();
            this.bindEvents(true);
            this.sortCall();
        },
        setElements : function () {
            var _this = this;
            this.topics = this.obj.find(this.opts.topics);
            this.topicsList = this.topics.find(this.opts.topicsList);
            this.productWrap = this.obj.find(this.opts.productWrap);
            this.product = this.productWrap.find(this.opts.product);
            this.productList = this.product.find(this.opts.productList);
            this.btnProductClose = this.productWrap.find(this.opts.productClose);
            this.category = this.obj.find(this.opts.category);
            this.categoryStep = this.category.find(this.opts.categoryStep).filter(function () {
                var target = $(this);
                if (!target.hasClass(_this.opts.categoryStepSort.split('.')[1]) && 
                    !target.hasClass(_this.opts.categoryResult.split('.')[1])) {
                    return true;
                } else {
                    return false;
                }
            });
            this.categoryTitle = this.categoryStep.find(this.opts.categoryTitle);
            this.categoryName = this.categoryTitle.find(this.opts.categoryName);
            this.categoryList = this.categoryStep.find(this.opts.categoryList);
            this.categorySortStep = this.category.find(this.opts.categoryStepSort);
            this.categorySortTitle = this.categorySortStep.find(this.opts.categoryTitle);
            this.categorySortName = this.categorySortTitle.find(this.opts.categoryName);
            this.categorySortList = this.categorySortStep.find(this.opts.categoryList);
            this.categorySortListUl = this.categorySortList.find(this.opts.categoryListUl);
        },
        initLayout : function () {
            this.product.hide();
            this.category.hide();
            this.categoryTitle.removeClass(this.opts.titleActiveClass);
            this.categorySortTitle.removeClass(this.opts.sortActiveClass);
        },
        changeEvents : function (event) {
            var events = [],
                eventNames = event.split(' ');
            for (var key in eventNames) {
                events.push(eventNames[key] + this.opts.customEvent);
            }
            return events.join(' ');
        },
        bindEvents : function (type) {
            if (type) {
                this.btnProductClose.on(this.changeEvents('click'), $.proxy(this.selectReset, this));
                this.categoryName.on(this.changeEvents('click'), $.proxy(this.toggleFunc, this));
                this.categoryList.on(this.changeEvents('click'), 'a', $.proxy(this.listFunc, this));
                this.categorySortList.on(this.changeEvents('click'), 'a', $.proxy(this.sortListFunc, this));
                this.categorySortName.on(this.changeEvents('click'), $.proxy(this.sortToggleFunc, this));
                $(win).on(this.changeEvents('resize orientationchange'), $.proxy(this.resizeFunc, this));
            } else {
                this.btnProductClose.off(this.changeEvents('click'));
                this.categoryName.off(this.changeEvents('click'));
                this.categoryList.off(this.changeEvents('click'));
                this.categorySortList.off(this.changeEvents('click'));
                this.categorySortName.off(this.changeEvents('click'));
                $(win).off(this.changeEvents('resize orientationchange'));
            }
        },
        resizeFunc : function () {
            this.winWidth = UTIL.winSize().w;
            if (this.opts.resizeStart == null) {
                this.opts.resizeStart = this.winWidth;
                this.resizeAnimateFunc();
            }
            win.clearTimeout(this.resizeEndTime);
            this.resizeEndTime = win.setTimeout($.proxy(this.resizeEndFunc, this), 150);
        },
        resizeEndFunc : function () {
            this.opts.resizeStart = null;
            this.setLayout();
            UTIL.cancelAFrame.call(win, this.resizeRequestFrame);
        },
        resizeAnimateFunc : function () {
            this.setLayout();
            this.resizeRequestFrame = UTIL.requestAFrame.call(win, $.proxy(this.resizeAnimateFunc, this));
        },
        setLayout : function () {
            if (UTIL.isSupportTransform) {
                if (this.winWidth <= BREAKPOINTS.MOBILE) {
                    if (this.opts.breakpointsMode !== 'MOBILE') {
                        this.opts.breakpointsMode = 'MOBILE';
                        this.categoryTitle.removeClass(this.opts.titleActiveClass);
                        this.categoryList.hide();
                        this.categorySortList.css('height', '');
                        this.categorySortListUl.css('height', '');
                    }
                } else {
                    this.setLayoutPC();
                }
            } else {
                this.setLayoutPC();
            }
        },
        setLayoutPC : function () {
            if (this.opts.breakpointsMode !== 'PC') {
                this.opts.breakpointsMode = 'PC';
                this.categoryTitle.removeClass(this.opts.titleActiveClass);
                this.categoryList.show();
            }
            if (this.opts.categoryViewType) {
                var categorySortListOffset = this.categorySortList.offset(),
                    categorySortStepOffset = this.categorySortStep.offset(),
                    offsetTopRange = categorySortListOffset.top - categorySortStepOffset.top,
                    categoryHeight = this.categoryStep.eq(0).outerHeight(),
                    sortHeight = categoryHeight - offsetTopRange;
                this.categorySortList.css('height', sortHeight - 2);
                this.categorySortListUl.css('height', sortHeight);
            }
        },
        sortCall : function () {
            this.topicSortCall = new win.smg.support.productSelect(this.topicsList[0], {
                onSelect : $.proxy(this.selectTopic, this)
            });
            this.productSolutionSortCall = new win.smg.support.productSelect(this.productList.eq(0)[0], {
                onSelect : $.proxy(this.selectProduct, this)
            });
            this.downloadUpdatesSortCall = new win.smg.support.productSelect(this.productList.eq(1)[0], {
                onSelect : $.proxy(this.selectProduct, this)
            });
        },
        selectTopic : function (data) {
            if (this.topicSelectType) {
                if (this.topicOldData == data) return;
                this.productWrap.find('[data-select-product="' + this.topicOldData + '"]').stop().slideUp(this.opts.duration, $.proxy(function () {
                    this.productSolutionSortCall.reInit();
                    this.downloadUpdatesSortCall.reInit();
                    this.productWrap.find('[data-select-product="' + data + '"]').stop().slideDown(this.opts.duration, $.proxy(function () {
                        this.scrollMoveFunc(this.productWrap);
                        this.slideCompleteFunc();
                    }, this));
                }, this));
            } else {
                this.topicSelectType = true;
                this.productWrap.find('[data-select-product="' + data + '"]').stop().slideDown(this.opts.duration, $.proxy(function () {
                    this.scrollMoveFunc(this.productWrap);
                    this.slideCompleteFunc();
                }, this));
            }
            this.categoryViewFunc(false);
            this.topicOldData = data;
        },
        selectProduct : function (data) {
            this.categoryViewFunc(true);
        },
        categoryViewFunc : function (type) {
            this.opts.categoryViewType = type;
            if (type) {
                this.category.stop().slideDown(this.opts.duration, $.proxy(function () {
                    if (this.winWidth <= BREAKPOINTS.MOBILE) {
                        this.scrollMoveFunc(this.category);
                    } else {
                        this.scrollMoveFunc(this.productWrap);
                    }
                    this.slideCompleteFunc();
                }, this));
            } else {
                this.category.stop().slideUp(this.opts.duration, $.proxy(this.slideCompleteFunc, this));
            }
        },
        selectReset : function (e) {
            e.preventDefault();
            this.topicOldData = null;
            this.topicSelectType = false;
            this.topicSortCall.reInit();
            this.product.filter(':visible').stop().slideUp(this.opts.duration, $.proxy(function () {
                this.productSolutionSortCall.reInit();
                this.downloadUpdatesSortCall.reInit();
                this.scrollMoveFunc(this.topics);
                this.slideCompleteFunc()
            }, this));
            this.categoryViewFunc(false);
        },
        toggleFunc : function (e) {
            e.preventDefault();
            if (UTIL.isSupportTransform) {
                var target = $(e.currentTarget),
                    targetStep = target.closest(this.opts.categoryStep),
                    targetTitle = targetStep.find(this.opts.categoryTitle),
                    targetList = targetStep.find(this.opts.categoryList);
                if (this.winWidth <= BREAKPOINTS.MOBILE) {
                    targetTitle.toggleClass(this.opts.titleActiveClass);
                    targetList.stop().slideToggle(this.opts.duration, $.proxy(this.slideCompleteFunc, this));
                }
            }
        },
        listFunc : function (e) {
            this.sortListFunc(e);
            var target = $(e.currentTarget),
                targetStep = target.closest(this.opts.categoryStep),
                targetName = targetStep.find(this.opts.categoryName);
            if (UTIL.isSupportTransform) {
                if (this.winWidth <= BREAKPOINTS.MOBILE) {
                    targetName.triggerHandler('click');
                }
            }
        },
        sortListFunc : function (e) {
            var target = $(e.currentTarget),
                targetLi = target.parent();
            if (!target.hasClass(this.opts.newWindowClass)) {
                e.preventDefault();
            }
            targetLi.addClass(this.opts.categoryActiveClass).siblings().removeClass(this.opts.categoryActiveClass);
            targetLi.attr('aria-selected', 'true').siblings().attr('aria-selected', 'false');
        },
        sortToggleFunc : function (e) {
            e.preventDefault();
            this.categorySortTitle.toggleClass(this.opts.sortActiveClass);
        },
        scrollMoveFunc : function (target) {
            if (!target.length) return;
            var scrollTop = Math.ceil(target.offset().top),
                winTop = $(win).scrollTop(),
                stickyHeight = PAGE.stickyArea(scrollTop);
            if (scrollTop === winTop) return;
            $('html, body').animate({
                'scrollTop' : scrollTop - stickyHeight
            }, this.opts.duration * 2);
        },
        slideCompleteFunc : function () {
            this.setLayout();
            this.outCallback('loadAfter');
        },
        outCallback : function (ing) {
            var callbackObj = this.opts[ing];
            if (callbackObj == null) return;
            callbackObj();
        },
        reInit : function () {
            // this.matchObj.reInit();
        },
        reEvents : function () {
            this.bindEvents(false);
            this.setElements();
            this.bindEvents(true);
        }
    };

    win.smg.support.threePersonaCall = function (args) {
        var defParams = {
            obj : '.three-persona'
        };
        this.opts = UTIL.def(defParams, (args || {}));
        if (!(this.obj = $(this.opts.obj)).length) return;
        this.init();
    };
    win.smg.support.threePersonaCall.prototype = UTIL.def({
        init : function () {
            this.callComponent();
            this.globalObjs();
        },
        callComponent : function () {
            this.callPlugins = [];
            for (var i = 0, max = this.obj.length; i < max; i++) {
                this.callPlugins.push(new win.smg.support[pluginName](this.obj.eq(i), {
                    loadAfter : $.proxy(this.globalObjsCall, this)
                }));
                this.obj.eq(i).data(pluginName, this.callPlugins[i]);
            }
        },
        globalObjs : function () {
            for (var i = 0, max = this.callPlugins.length; i < max; i++) {
                CST_EVENT.PAGEIS.PAGEOBJS.push(this.callPlugins[i]);
            }
        },
        globalObjsCall : function () {
            CST_EVENT.PAGEIS.EVENT_MANAGER.trigger(CST_EVENT.PAGEIS.REPOSITION);
        },
        reEvents : function (component) {
            if (component) {
                $(component).data(pluginName).reEvents();
            } else {
                for (var i = 0, max = this.callPlugins.length; i < max; i++) {
                    this.callPlugins[i].reEvents();
                }
            }
        }
    }, UTIL.emitter);
    $(function () {
        win.supportThreePersona = new win.smg.support.threePersonaCall();
    });
})(window, window.jQuery, window.document);